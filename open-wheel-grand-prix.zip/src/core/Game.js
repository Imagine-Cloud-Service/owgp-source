import * as THREE from 'three';
import { STEP, TRACK, TRACKS, RACE, WEATHER, ERS, TYRES, PHYSICS } from '../config.js';
import { CarPhysics } from '../physics/CarPhysics.js';
import { Track } from '../world/Track.js';
import { Environment } from '../world/Environment.js';
import { buildCar, buildSafetyCar, poseCar } from '../vehicle/CarModel.js';
import { CameraRig } from '../camera/CameraRig.js';
import { Input } from './Input.js';
import { HUD, fmt } from '../ui/HUD.js';
import { EngineAudio } from '../audio/EngineAudio.js';

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const angleDelta = (a, b) => Math.atan2(Math.sin(a - b), Math.cos(a - b));
const TEAM_COLORS = [
  { primary: '#28b7d2', secondary: '#f5f2e9', helmet: '#ffcc39' },
  { primary: '#e54b45', secondary: '#20252c', helmet: '#ece5d8' },
  { primary: '#ebbf3c', secondary: '#20252c', helmet: '#e84c43' },
  { primary: '#8b6ee8', secondary: '#f5f2e9', helmet: '#64ce93' },
  { primary: '#47a76a', secondary: '#20252c', helmet: '#f2e4b8' },
];

export class Game {
  constructor(container, setup) {
    this.setup = { laps: 3, fuelKg: 40, tyre: 'medium', horizontalFov: 45, ...setup };
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    const qualityScale = { low: 1, medium: 1.35, high: 1.8 }[this.setup.quality] || 1.8;
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, qualityScale));
    this.renderer.shadowMap.enabled = this.setup.quality !== 'low'; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(70, 1, 0.3, 4000);
    this.track = new Track(TRACKS[this.setup.track] || TRACK);
    this.scene.add(this.track.group);
    this.env = new Environment(this.scene, this.track, this.setup.quality);
    this.weather = { wetness: WEATHER[this.setup.weather] ?? 0 };
    this.env.setWeather?.(this.weather.wetness);
    this.track.setWetness(this.weather.wetness);
    this.car = buildCar(this.setup.livery); this.scene.add(this.car.group);
    this.physics = new CarPhysics(this.setup.fuelKg);
    this.ai = this.createOpponents();
    this.safetyCarVisual = buildSafetyCar(); this.safetyCarVisual.group.visible = false; this.scene.add(this.safetyCarVisual.group);
    this.safetyCarPhysics = new CarPhysics(1350);
    this.input = new Input(this.setup); this.rig = new CameraRig(this.camera, this.setup.horizontalFov, this.setup.gForce ?? 1);
    document.getElementById('touchControls').style.display = this.setup.controlsMode === 'keyboard' ? 'none' : '';
    this.hud = new HUD(this.track);
    this.audio = new EngineAudio({ volume: this.setup.audioVolume ?? 0.65, muted: this.setup.audioMuted ?? false });
    this.acc = 0; this.last = performance.now(); this.frameId = 0;
    this.resizeHandler = () => this.resize(); addEventListener('resize', this.resizeHandler); this.resize();
    this.resetToGrid();
  }

  createOpponents() {
    const drivers = ['M. Riva', 'A. Novak', 'J. Kim', 'L. Sato', 'E. Silva'];
    return drivers.map((name, i) => {
      const car = buildCar(TEAM_COLORS[i]); this.scene.add(car.group);
      const physics = new CarPhysics(28);
      return { name, car, physics, lane: [-4.5, 4.5, -4.5, 4.5, 0][i], pace: [0.95, 0.99, 0.92, 1.02, 0.97][i], hint: -1, previousS: null, completedLaps: 0, progress: 0, tyreWear: 0 };
    });
  }

  resize() { this.renderer.setSize(innerWidth, innerHeight); this.camera.aspect = innerWidth / innerHeight; this.camera.updateProjectionMatrix(); }

  resetToGrid() {
    const start = this.track.N - 7, p = this.track.samples[start], t = this.track.tangents[start];
    this.physics.reset(p.x, p.z, Math.atan2(t.z, t.x));
    const right = this.track.rights[start];
    this.ai.forEach((driver, i) => {
      const index = (start - Math.floor((i + 1) * 9 / this.track.step) + this.track.N) % this.track.N;
      const q = this.track.samples[index], r = this.track.rights[index], tangent = this.track.tangents[index];
      driver.physics.reset(q.x + r.x * driver.lane, q.z + r.z * driver.lane, Math.atan2(tangent.z, tangent.x));
      driver.hint = index; driver.previousS = null; driver.completedLaps = 0; driver.progress = 0; driver.tyreWear = 0;
    });
    this.hint = start; this.mode = 'countdown'; this.t = 0; this.raceTime = 0; this.lapStart = 0;
    this.lap = 1; this.lastLap = null; this.bestLap = null; this.sectorsHit = 7; this.prevS = null; this.sector = 0;
    this.pitTimer = 0; this.pitUsed = false; this.pitCompound = this.setup.tyre;
    this.fuelKg = this.setup.fuelKg; this.physics.mass = PHYSICS.m + this.fuelKg;
    this.fuelWarning = false;
    this.tyre = this.setup.tyre; this.tyreWear = 0; this.ersMJ = ERS.capacityMJ; this.ersEnabled = false;
    this.drsEnabled = false; this.drsAllowed = false; this.safetyCarTimer = 0; this.safetyCarLaps = 0;
    this.trackWarnings = 0; this.limitOutsideTime = 0; this.limitArmed = true; this.timePenalty = 0; this.damage = 0;
    this.collisionCooldown = 0; this.lastContact = 0; this.pitLimiter = false; this.pitLaneS = null;
    this.safetyCarVisual.group.visible = false;
    this.hud?.setRaceInfo({ weather: this.setup.weather, laps: this.setup.laps, track: this.track.spec.name, driver: this.setup.driver, team: this.setup.team });
  }

  start() { this.audio.start(); this.hud.show(); this.rig.snap = true; this.frameId = requestAnimationFrame(t => this.frame(t)); }

  restart() {
    document.getElementById('finishMenu').classList.add('gone');
    document.getElementById('pauseMenu').classList.add('gone');
    this.resetToGrid(); this.hud.show(); this.last = performance.now(); this.acc = 0;
  }

  stop() {
    cancelAnimationFrame(this.frameId); this.audio.stop(); removeEventListener('resize', this.resizeHandler);
    this.renderer.dispose(); this.renderer.domElement.remove();
  }

  togglePause() {
    if (this.mode === 'paused') this.resume();
    else if (this.mode === 'racing' || this.mode === 'countdown') {
      this.mode = 'paused'; document.getElementById('pauseMenu').classList.remove('gone');
    }
  }
  resume() { if (this.mode !== 'paused') return; this.mode = 'racing'; document.getElementById('pauseMenu').classList.add('gone'); this.last = performance.now(); }

  frame(now) {
    this.frameId = requestAnimationFrame(t => this.frame(t));
    const dt = Math.min(0.05, (now - this.last) / 1000); this.last = now;
    this.input.poll(dt);
    if (this.input.pressed('KeyP') || this.input.pressed('Escape')) this.togglePause();
    if (this.input.pressed('KeyM')) this.requestPit();
    if (this.input.toggleCamera()) this.rig.toggle();
    if (this.input.toggleHalo()) { this.rig.toggleHalo(); this.hud.toast(this.rig.hideCenterPillar ? 'Halo center pillar hidden' : 'Halo center pillar visible'); }
    if (this.input.toggleERS()) { this.ersEnabled = !this.ersEnabled; this.hud.toast(this.ersEnabled ? 'ERS deployment armed' : 'ERS deployment off'); }
    if (this.input.toggleDRS()) {
      if (this.drsAllowed) { this.drsEnabled = !this.drsEnabled; this.hud.toast(this.drsEnabled ? 'DRS open' : 'DRS closed'); }
      else this.hud.toast('DRS unavailable: zone or gap condition not met');
    }
    if (this.input.reset()) this.recover();
    this.acc += dt;
    for (let n = 0; this.acc >= STEP && n < 12; n++, this.acc -= STEP) this.update(STEP);
    this.render(dt); this.input.endFrame();
  }

  update(dt) {
    if (this.mode === 'paused' || this.mode === 'finished') return;
    this.t += dt;
    let cmd = { throttle: this.input.throttle, brake: this.input.brake, steer: this.input.steer };
    if (this.mode === 'countdown') {
      cmd = { throttle: 0, brake: 1, steer: 0 };
      const lit = Math.min(5, Math.floor(this.t - 0.5));
      if (this.t > 6.2) { this.mode = 'racing'; this.hud.lights(0, false); this.hud.toast('Go!', 900); }
      else this.hud.lights(Math.max(0, lit), true);
    } else {
      this.raceTime += dt;
      if (this.setup.weather === 'changeable') {
        const wetness = clamp(0.38 + Math.sin(this.raceTime * 0.045) * 0.34, 0, 0.78);
        if (Math.abs(wetness - this.weather.wetness) > 0.015) { this.weather.wetness = wetness; this.env.setWeather(wetness); this.track.setWetness(wetness); }
      }
      if (this.safetyCarTimer > 0) {
        this.safetyCarTimer = Math.max(0, this.safetyCarTimer - dt);
        if (!this.safetyCarTimer) { this.hud.toast('Safety car in this lap'); this.safetyCarLaps = 0; }
      }
      if (this.collisionCooldown > 0) this.collisionCooldown -= dt;
      if (this.pitTimer > 0) {
        this.pitTimer = Math.max(0, this.pitTimer - dt); cmd = { throttle: 0, brake: 1, steer: 0 };
        if (!this.pitTimer) {
          this.tyre = this.pitCompound; this.tyreWear = 0;
          this.hud.toast(`Pit service complete · ${this.tyre.toUpperCase()} tyres fitted`);
        }
      }
    }

    const s = this.physics.s, info = this.track.query(s.x, s.z, this.hint); this.hint = info.index;
    this.updateTrackLimits(dt, info);
    this.pitLaneS = this.inPitLane(info) ? info.s : null;
    this.pitLimiter = this.pitLaneS !== null;
    if (this.pitLimiter && this.physics.speed > RACE.pitSpeedKmh / 3.6) { cmd.throttle = 0; cmd.brake = Math.max(cmd.brake, 0.65); }
    if (this.safetyCarTimer > 0) {
      cmd.throttle = Math.min(cmd.throttle, this.physics.speed > 22 ? 0 : 0.2);
      if (this.physics.speed > 23) cmd.brake = Math.max(cmd.brake, 0.55);
      this.drsEnabled = false;
    }

    this.drsAllowed = this.checkDrs(info.s);
    if (!this.drsAllowed) this.drsEnabled = false;
    if (this.fuelKg <= 0) cmd.throttle = 0;
    cmd.throttle *= Math.max(0.25, 1 - this.damage * 0.6);
    cmd.steer *= Math.max(0.45, 1 - this.damage * 0.45);
    cmd.drs = this.drsEnabled;
    cmd.ersPower = this.ersEnabled && this.ersMJ > 0 && cmd.throttle > 0 ? ERS.deploymentKW * 1000 : 0;
    const grip = this.surfaceGrip(info.lateral, this.tyreWear, this.tyre);
    const beforeDistance = this.physics.speed * dt;
    this.physics.step(dt, cmd, { grip });
    this.updateStrategy(dt, beforeDistance, cmd);
    this.handleBarrier(this.physics, info);
    this.updateOpponents(dt);
    if (this.safetyCarTimer > 0) this.updateSafetyCar(dt);
    this.resolveCarCollisions();
    this.laps(info.s);
  }

  surfaceGrip(lateral, wear = 0, tyre = 'medium') {
    const off = Math.abs(lateral), half = this.track.width / 2;
    let grip = off < half ? 1 : off < half + this.track.spec.kerb ? 0.95 : 0.55;
    return Math.max(0.2, grip * (1 - 0.38 * this.weather.wetness) * TYRES[tyre].grip * (1 - wear / 100 * 0.38));
  }

  inPitLane(info) {
    const p = this.track.pitLane, q = info.s / this.track.length;
    return p && q >= p.start && q <= p.end && info.lateral >= p.offset - p.width / 2 && info.lateral <= p.offset + p.width / 2;
  }

  checkDrs(distance) {
    return this.isDrsEligible(distance, (this.lap - 1) * this.track.length + distance, this.physics.speed, this.ai);
  }

  isDrsEligible(distance, progress, speed, pack) {
    if (this.safetyCarTimer > 0 || this.weather.wetness > 0.62 || this.setup.weather === 'wet') return false;
    const q = distance / this.track.length;
    const inZone = this.track.spec.drsZones?.some(([a, b]) => q >= a && q <= b);
    if (!inZone || speed < 30) return false;
    const gap = Math.min(...pack.filter(driver => driver.progress > progress).map(driver => driver.progress - progress), Infinity);
    return gap <= speed;
  }

  updateTrackLimits(dt, info) {
    const outside = Math.abs(info.lateral) > this.track.width / 2 + this.track.spec.kerb + 0.2 && !this.inPitLane(info);
    if (outside) { this.limitOutsideTime += dt; return; }
    if (this.limitOutsideTime > 0.65 && this.limitArmed && this.mode === 'racing') {
      this.trackWarnings++; this.limitArmed = false;
      if (this.trackWarnings <= 3) this.hud.toast(`Track limits warning ${this.trackWarnings}/3`, 1400);
      else { this.timePenalty += 5; this.hud.toast('5 second track-limits penalty', 1800); }
    }
    if (!outside) { this.limitOutsideTime = 0; this.limitArmed = true; }
  }

  updateStrategy(dt, distance, cmd) {
    const fuelRate = 0.035 + cmd.throttle * 0.12 + this.physics.speed * 0.0005;
    this.fuelKg = Math.max(0, this.fuelKg - fuelRate * dt);
    this.physics.mass = PHYSICS.m + this.fuelKg;
    if (this.fuelKg < 5 && !this.fuelWarning) { this.fuelWarning = true; this.hud.toast('Low fuel · manage throttle'); }
    if (this.ersEnabled && cmd.ersPower > 0) this.ersMJ = Math.max(0, this.ersMJ - (cmd.ersPower / 1000) * dt / 1000);
    else this.ersMJ = Math.min(ERS.capacityMJ, this.ersMJ + cmd.brake * ERS.regenKW * dt / 1000);
    if (this.ersMJ <= 0.001) this.ersEnabled = false;
    const wearRate = TYRES[this.tyre].wear * (this.weather.wetness > 0.6 ? 0.68 : 1);
    this.tyreWear = clamp(this.tyreWear + distance * 0.0012 * wearRate * (1 + Math.min(2, Math.abs(this.physics.s.ay) / 9.81) * 0.28), 0, 100);
  }

  handleBarrier(physics, info) {
    const off = Math.abs(info.lateral), wall = this.track.wallOffset;
    if (off > wall) {
      const sign = Math.sign(info.lateral), over = off - wall, s = physics.s;
      const normalX = info.right.x * sign, normalZ = info.right.z * sign, velocity = this.worldVelocity(physics);
      const impactSpeed = Math.max(0, velocity.x * normalX + velocity.z * normalZ);
      s.x -= info.right.x * sign * over; s.z -= info.right.z * sign * over;
      physics.collide(normalX, normalZ);
      if (physics === this.physics && impactSpeed > 10 && this.collisionCooldown <= 0) {
        this.collisionCooldown = 1.6;
        this.damage = clamp(this.damage + Math.min(0.08, (impactSpeed - 10) * 0.0015), 0, 0.7);
        this.input.forceFeedback(0, Math.min(1, impactSpeed / 28));
        this.deploySafetyCar(impactSpeed);
      }
    }
  }

  resolveCarCollisions() {
    const cars = [{ physics: this.physics, player: true }, ...this.ai.map(driver => ({ physics: driver.physics, player: false }))];
    const radius = RACE.carHitRadius;
    for (let i = 0; i < cars.length; i++) for (let j = i + 1; j < cars.length; j++) {
      const a = cars[i].physics, b = cars[j].physics, sa = a.s, sb = b.s;
      let dx = sa.x - sb.x, dz = sa.z - sb.z, dist = Math.hypot(dx, dz);
      if (dist >= radius) continue;
      if (dist < 1e-4) { dx = 1; dz = 0; dist = 1; }
      const nx = dx / dist, nz = dz / dist, overlap = radius - dist;
      sa.x += nx * overlap * 0.51; sa.z += nz * overlap * 0.51;
      sb.x -= nx * overlap * 0.49; sb.z -= nz * overlap * 0.49;
      const va = this.worldVelocity(a), vb = this.worldVelocity(b);
      const closing = (va.x - vb.x) * nx + (va.z - vb.z) * nz;
      if (closing >= 0) continue;
      const restitution = 0.28, impulse = -(1 + restitution) * closing / (1 / a.mass + 1 / b.mass);
      va.x += impulse * nx / a.mass; va.z += impulse * nz / a.mass;
      vb.x -= impulse * nx / b.mass; vb.z -= impulse * nz / b.mass;
      this.setWorldVelocity(a, va); this.setWorldVelocity(b, vb);
      sa.r += (nz * 0.12); sb.r -= (nz * 0.12);
      const impact = Math.abs(closing);
      if (cars[i].player || cars[j].player) {
        this.damage = clamp(this.damage + Math.min(0.12, impact * 0.0022), 0, 0.7);
        if (impact > 1.5) this.input.forceFeedback(0, Math.min(1, impact / 22));
        if (impact > 8 && this.collisionCooldown <= 0) {
          this.collisionCooldown = 1.6; this.hud.toast(`Car contact · impact ${impact.toFixed(0)} m/s`, 1300);
          this.deploySafetyCar(impact);
        }
      }
    }
  }

  worldVelocity(physics) {
    const s = physics.s, c = Math.cos(s.th), n = Math.sin(s.th);
    return { x: s.vx * c - s.vy * n, z: s.vx * n + s.vy * c };
  }

  setWorldVelocity(physics, v) {
    const s = physics.s, c = Math.cos(s.th), n = Math.sin(s.th);
    s.vx = v.x * c + v.z * n; s.vy = -v.x * n + v.z * c;
  }

  deploySafetyCar(impact) {
    if (impact < 13 || this.safetyCarTimer > 0 || this.mode !== 'racing') return;
    this.safetyCarTimer = RACE.safetyCarSeconds; this.safetyCarLaps++;
    const info = this.track.query(this.physics.s.x, this.physics.s.z, this.hint);
    const ahead = (info.index + Math.max(10, Math.floor(350 / this.track.step))) % this.track.N;
    const point = this.track.samples[ahead], tangent = this.track.tangents[ahead];
    this.safetyCarPhysics.reset(point.x, point.z, Math.atan2(tangent.z, tangent.x)); this.safetyHint = ahead;
    this.safetyCarVisual.group.visible = true;
    this.drsEnabled = false; this.hud.toast('SAFETY CAR DEPLOYED · HOLD PACE', 2600);
  }

  updateSafetyCar(dt) {
    const s = this.safetyCarPhysics.s, info = this.track.query(s.x, s.z, this.safetyHint); this.safetyHint = info.index;
    const targetIndex = (info.index + Math.max(5, Math.floor(38 / this.track.step))) % this.track.N;
    const target = this.track.samples[targetIndex], desired = Math.atan2(target.z - s.z, target.x - s.x);
    const error = angleDelta(desired, s.th), speed = this.safetyCarPhysics.speed, targetSpeed = 24;
    this.safetyCarPhysics.step(dt, {
      steer: clamp(error * 1.8 - s.r * 0.24, -0.75, 0.75),
      throttle: clamp((targetSpeed - speed) * 0.28, 0, 0.7),
      brake: clamp((speed - targetSpeed - 1) * 0.3, 0, 1),
    }, { grip: this.surfaceGrip(info.lateral) });
  }

  updateOpponents(dt) {
    const L = this.track.length;
    for (const driver of this.ai) {
      const phys = driver.physics, s = phys.s;
      const info = this.track.query(s.x, s.z, driver.hint); driver.hint = info.index;
      const next = Math.max(5, Math.floor((24 + phys.speed * 0.45) / this.track.step));
      const targetIndex = (info.index + next) % this.track.N;
      const target = this.track.samples[targetIndex], right = this.track.rights[targetIndex];
      const tx = target.x + right.x * driver.lane, tz = target.z + right.z * driver.lane;
      const desired = Math.atan2(tz - s.z, tx - s.x), error = angleDelta(desired, s.th);
      const progress = driver.completedLaps * L + info.s;
      const drs = this.isDrsEligible(info.s, progress, phys.speed, this.ai.filter(other => other !== driver));
      driver.drs = drs;
      const targetSpeed = (this.safetyCarTimer > 0 ? 23 : this.setup.weather === 'wet' ? 67 : 78) * driver.pace;
      const input = this.mode === 'racing' ? {
        steer: clamp(error * 2.1 - s.r * 0.22, -1, 1),
        throttle: clamp((targetSpeed - phys.speed) * 0.32, 0, 1),
        brake: clamp((phys.speed - targetSpeed - 3) * 0.22, 0, 1),
        drs,
      } : { throttle: 0, brake: 1, steer: 0 };
      phys.step(dt, input, { grip: this.surfaceGrip(info.lateral, driver.tyreWear, 'medium') }); this.handleBarrier(phys, info);
      driver.tyreWear = clamp(driver.tyreWear + phys.speed * dt * 0.00055, 0, 100);
      const now = this.track.query(s.x, s.z, driver.hint); driver.hint = now.index;
      if (driver.previousS != null && driver.previousS > L * 0.85 && now.s < L * 0.15) driver.completedLaps++;
      driver.previousS = now.s; driver.progress = driver.completedLaps * L + now.s;
    }
  }

  laps(sd) {
    const L = this.track.length;
    this.sector = Math.floor((sd / L) * 3); this.sectorsHit |= 1 << this.sector;
    if (this.prevS !== null && this.prevS > L * 0.85 && sd < L * 0.15) {
      if (this.sectorsHit === 7 && this.mode === 'racing') {
        const lt = this.raceTime - this.lapStart; this.lastLap = lt;
        this.bestLap = this.bestLap == null ? lt : Math.min(this.bestLap, lt);
        this.hud.toast(lt === this.bestLap ? `Best lap ${fmt(lt)}` : `Lap ${fmt(lt)}`);
        this.lap++; if (this.lap > this.setup.laps) this.finishRace();
      }
      this.lapStart = this.raceTime; this.sectorsHit = 1 << this.sector;
    }
    this.prevS = sd;
  }

  position() {
    const me = (this.lap - 1) * this.track.length + this.track.query(this.physics.s.x, this.physics.s.z, this.hint).s;
    return 1 + this.ai.filter(x => x.progress > me).length;
  }

  requestPit() {
    if (this.mode !== 'racing' || this.pitUsed || this.pitTimer > 0) return;
    const info = this.track.query(this.physics.s.x, this.physics.s.z, this.hint);
    if (!this.inPitLane(info) || Math.abs(info.s / this.track.length - this.track.pitLane.box) > 0.013) {
      this.hud.toast('Enter the marked pit lane and stop in your pit box'); return;
    }
    if (this.physics.speed * 3.6 > RACE.pitSpeedKmh) { this.hud.toast(`Slow to ${RACE.pitSpeedKmh} km/h to pit`); return; }
    this.pitCompound = document.getElementById('pitTyreSelect').value;
    this.pitUsed = true; this.pitTimer = RACE.pitServiceSeconds; this.hud.toast('Pit crew changing tyres');
  }

  finishRace() {
    this.mode = 'finished'; this.hud.lights(0, false);
    document.getElementById('finishTitle').textContent = this.position() === 1 ? 'Race winner' : 'Race complete';
    document.getElementById('finishSummary').textContent = `${this.setup.driver} finished P${this.position()} · ${this.lap - 1} laps · best lap ${fmt(this.bestLap)}${this.timePenalty ? ` · +${this.timePenalty}s penalty` : ''}`;
    document.getElementById('finishMenu').classList.remove('gone');
  }

  recover() {
    const i = this.track.query(this.physics.s.x, this.physics.s.z, this.hint).index, p = this.track.samples[i], t = this.track.tangents[i];
    this.physics.reset(p.x, p.z, Math.atan2(t.z, t.x)); this.sectorsHit = 0; this.hud.toast('Reset to track', 1000);
  }

  render(dt) {
    const s = this.physics.s;
    const info = this.track.query(s.x, s.z, this.hint);
    poseCar(this.car, s, this.drsEnabled); this.env.follow(s.x, s.z); this.rig.update(dt, s, this.car, { drs: this.drsEnabled });
    for (const driver of this.ai) poseCar(driver.car, driver.physics.s, driver.drs);
    if (this.safetyCarTimer > 0) {
      poseCar(this.safetyCarVisual, this.safetyCarPhysics.s);
      const flash = Math.floor(performance.now() / 150) % 2;
      this.safetyCarVisual.beacons[0].emissiveIntensity = flash ? 2.4 : 0.25;
      this.safetyCarVisual.beacons[1].emissiveIntensity = flash ? 0.25 : 2.4;
    }
    else this.safetyCarVisual.group.visible = false;
    this.audio.update(s.rpm, this.input.throttle, { speed: this.physics.speed, lateralG: s.ay / 9.81, grip: this.surfaceGrip(info.lateral, this.tyreWear, this.tyre), gear: s.gear });
    const me = this.track.query(s.x, s.z, this.hint).s;
    const position = 1 + this.ai.filter(x => x.progress > (this.lap - 1) * this.track.length + me).length;
    const q = info.s / this.track.length;
    const pitBox = this.inPitLane(info) && Math.abs(q - this.track.pitLane.box) <= 0.013;
    this.input.forceFeedback(clamp(-s.delta * 1.4 - s.ay / 9.81 * 0.18, -1, 1));
    this.hud.update({ lap: Math.min(this.lap, this.setup.laps), cur: this.raceTime - this.lapStart, last: this.lastLap, best: this.bestLap,
      sector: this.sector, gear: s.gear, speed: this.physics.speed, rpm: s.rpm, cam: this.rig.name, x: s.x, z: s.z, position,
      pitUsed: this.pitUsed, inPitLane: this.pitLimiter, pitBox, fuel: this.fuelKg, tyre: this.tyre, tyreWear: this.tyreWear,
      ers: this.ersMJ, ersOn: this.ersEnabled, drs: this.drsEnabled, drsAllowed: this.drsAllowed,
      safetyCar: this.safetyCarTimer > 0, safetySeconds: this.safetyCarTimer, haloHidden: this.rig.hideCenterPillar, damage: this.damage,
      grip: this.surfaceGrip(info.lateral, this.tyreWear, this.tyre), wetness: this.weather.wetness });
    this.renderer.render(this.scene, this.camera);
  }
}
