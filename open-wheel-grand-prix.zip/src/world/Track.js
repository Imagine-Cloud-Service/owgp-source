import * as THREE from 'three';
import { TRACK } from '../config.js';

export class Track {
  constructor(spec = TRACK) {
    this.spec = spec;
    this.width = spec.width; this.wallOffset = spec.wallOffset; this.N = spec.samples;
    const pts = spec.points.map(([x, z]) => new THREE.Vector3(x, 0, z));
    let curve = new THREE.CatmullRomCurve3(pts, true, 'centripetal');
    const drawnLength = curve.getLength();
    if (spec.targetLength && drawnLength > 0) {
      const scale = spec.targetLength / drawnLength;
      for (const p of pts) p.multiplyScalar(scale);
      curve = new THREE.CatmullRomCurve3(pts, true, 'centripetal');
    }
    this.length = spec.targetLength || curve.getLength();
    this.samples = curve.getSpacedPoints(this.N).slice(0, this.N);
    this.step = this.length / this.N;
    const N = this.N;
    this.tangents = this.samples.map((_, i) => {
      const a = this.samples[(i + 1) % N], b = this.samples[(i - 1 + N) % N];
      return new THREE.Vector3(a.x - b.x, 0, a.z - b.z).normalize();
    });
    this.rights = this.tangents.map(t => new THREE.Vector3(-t.z, 0, t.x));
    this.pitLane = spec.pit ? { ...spec.pit } : null;
    this.group = new THREE.Group();
    this._build();
  }

  /** Nearest centre-line sample, lateral offset (+ = right), and distance along the lap. */
  query(x, z, hint = -1) {
    const N = this.N; let best = 0, bd = Infinity;
    const lo = hint < 0 ? 0 : -60, hi = hint < 0 ? N - 1 : 60;
    for (let k = lo; k <= hi; k++) {
      const i = hint < 0 ? k : (hint + k + N) % N, p = this.samples[i];
      const d = (x - p.x) ** 2 + (z - p.z) ** 2;
      if (d < bd) { bd = d; best = i; }
    }
    const p = this.samples[best], t = this.tangents[best], r = this.rights[best];
    const dx = x - p.x, dz = z - p.z;
    const along = dx * t.x + dz * t.z, lateral = dx * r.x + dz * r.z;
    const s = (((best + along / this.step) * this.step) % this.length + this.length) % this.length;
    return { index: best, lateral, s, tangent: t, right: r };
  }

  _ribbon(oa, ob, ya, yb, colorOf, mat) {
    const pos = [], col = [], idx = [], N = this.N;
    for (let i = 0; i < N; i++) {
      const p0 = this.samples[i], p1 = this.samples[(i + 1) % N], r0 = this.rights[i], r1 = this.rights[(i + 1) % N];
      const c = colorOf(i), base = pos.length / 3;
      pos.push(p0.x + r0.x * oa, ya, p0.z + r0.z * oa, p0.x + r0.x * ob, yb, p0.z + r0.z * ob,
               p1.x + r1.x * oa, ya, p1.z + r1.z * oa, p1.x + r1.x * ob, yb, p1.z + r1.z * ob);
      for (let k = 0; k < 4; k++) col.push(c.r, c.g, c.b);
      idx.push(base, base + 1, base + 2, base + 1, base + 3, base + 2);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    geo.setIndex(idx); geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, mat); mesh.receiveShadow = true;
    this.group.add(mesh); return mesh;
  }

  _build() {
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, flatShading: true, side: THREE.DoubleSide });
    const edgeMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.82, flatShading: true, side: THREE.DoubleSide });
    this.asphaltMaterial = mat; this.edgeMaterial = edgeMat;
    const asphalt = [new THREE.Color(0x3a3f47), new THREE.Color(0x353a42)];
    const kerb = [new THREE.Color(0xe03a3e), new THREE.Color(0xf4f6f8)];
    const wall = [new THREE.Color(0xd8dde2), new THREE.Color(0x8a96a3)];
    const half = this.width / 2, k = this.spec.kerb;
    this._ribbon(-half, half, 0.03, 0.03, i => asphalt[(i >> 2) & 1], mat);
    this._ribbon(half, half + k, 0.05, 0.05, i => kerb[(i >> 1) & 1], edgeMat);
    this._ribbon(-half - k, -half, 0.05, 0.05, i => kerb[(i >> 1) & 1], edgeMat);
    const w = this.wallOffset;
    this._ribbon(w, w, 0, 1.3, i => wall[(i >> 3) & 1], edgeMat);
    this._ribbon(-w, -w, 0, 1.3, i => wall[(i >> 3) & 1], edgeMat);

    // start/finish chequer
    const cv = document.createElement('canvas'); cv.width = 32; cv.height = 128;
    const cx = cv.getContext('2d');
    for (let y = 0; y < 8; y++) for (let x = 0; x < 2; x++) { cx.fillStyle = (x + y) % 2 ? '#111' : '#fff'; cx.fillRect(x * 16, y * 16, 16, 16); }
    const tex = new THREE.CanvasTexture(cv); tex.magFilter = THREE.NearestFilter;
    const line = new THREE.Mesh(new THREE.PlaneGeometry(2.4, this.width).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: tex }));
    line.position.set(this.samples[0].x, 0.06, this.samples[0].z);
    line.rotation.y = -Math.atan2(this.tangents[0].z, this.tangents[0].x);
    this.group.add(line);
    this._buildPitLane();
    this._buildDrsSigns();
  }

  _buildPitLane() {
    if (!this.pitLane) return;
    const { start, end, offset, width } = this.pitLane, verts = [], idx = [];
    const first = Math.floor(start * this.N), last = Math.floor(end * this.N);
    for (let j = first; j <= last; j++) {
      const i = j % this.N, p = this.samples[i], r = this.rights[i], base = verts.length / 3;
      verts.push(p.x + r.x * (offset - width / 2), 0.045, p.z + r.z * (offset - width / 2),
        p.x + r.x * (offset + width / 2), 0.045, p.z + r.z * (offset + width / 2));
      if (j < last) idx.push(base, base + 1, base + 2, base + 1, base + 3, base + 2);
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3)); geometry.setIndex(idx); geometry.computeVertexNormals();
    this.pitMaterial = new THREE.MeshStandardMaterial({ color: 0x252b31, roughness: 0.84, side: THREE.DoubleSide });
    this.group.add(new THREE.Mesh(geometry, this.pitMaterial));
    for (let q = start; q <= end; q += 0.025) {
      const p = this.samples[Math.floor(q * this.N) % this.N], r = this.rights[Math.floor(q * this.N) % this.N];
      const line = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.025, 0.45), new THREE.MeshBasicMaterial({ color: 0xf2f0df }));
      line.position.set(p.x + r.x * offset, 0.07, p.z + r.z * offset); line.rotation.y = -Math.atan2(this.tangents[Math.floor(q * this.N) % this.N].z, this.tangents[Math.floor(q * this.N) % this.N].x);
      this.group.add(line);
    }
    const boxIndex = Math.floor(this.pitLane.box * this.N), p = this.samples[boxIndex], r = this.rights[boxIndex];
    const mark = new THREE.Mesh(new THREE.BoxGeometry(5.5, 0.025, this.pitLane.width - 0.6), new THREE.MeshBasicMaterial({ color: 0xf1ead4, transparent: true, opacity: 0.7 }));
    mark.position.set(p.x + r.x * this.pitLane.offset, 0.08, p.z + r.z * this.pitLane.offset);
    mark.rotation.y = -Math.atan2(this.tangents[boxIndex].z, this.tangents[boxIndex].x); this.group.add(mark);
  }

  setWetness(wetness) {
    const wet = Math.max(0, Math.min(1, wetness));
    this.asphaltMaterial.roughness = 0.9 - wet * 0.62;
    if (this.pitMaterial) this.pitMaterial.roughness = 0.84 - wet * 0.55;
    this.edgeMaterial.roughness = 0.82 - wet * 0.25;
  }

  _buildDrsSigns() {
    if (!this.spec.drsZones) return;
    for (const [start, end] of this.spec.drsZones) for (const [q, label] of [[start, 'DRS'], [end, 'END DRS']]) {
      const i = Math.floor(q * this.N), p = this.samples[i], r = this.rights[i], t = this.tangents[i];
      const canvas = document.createElement('canvas'); canvas.width = 256; canvas.height = 112;
      const c = canvas.getContext('2d'); c.fillStyle = '#123347'; c.fillRect(0, 0, 256, 112);
      c.fillStyle = '#d6ef61'; c.font = '800 60px Arial'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(label, 128, 56);
      const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(3.1, 1.35), new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide }));
      const side = 1, offset = this.wallOffset + 2.6;
      sign.position.set(p.x + r.x * side * offset, 4.6, p.z + r.z * side * offset);
      sign.rotation.y = -Math.atan2(t.z, t.x) - Math.PI / 2; this.group.add(sign);
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.16, 4.2, 0.16), new THREE.MeshStandardMaterial({ color: 0x313b42 }));
      post.position.set(sign.position.x, 2.1, sign.position.z); this.group.add(post);
    }
  }
}
