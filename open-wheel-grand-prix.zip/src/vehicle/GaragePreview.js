import * as THREE from 'three';
import { buildCar } from './CarModel.js';

const palette = { primary: '#e03a3e', secondary: '#f4f6f8', helmet: '#ffc400', halo: '#20252c', rims: '#f4f6f8', number: 1 };

export class GaragePreview {
  constructor(container, livery = palette, quality = 'high') {
    this.container = container; this.livery = { ...palette, ...livery }; this.quality = quality;
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, quality === 'low' ? 1 : 1.6));
    this.renderer.shadowMap.enabled = quality !== 'low'; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace; container.appendChild(this.renderer.domElement);
    this.scene = new THREE.Scene(); this.scene.background = new THREE.Color(0x101820); this.scene.fog = new THREE.Fog(0x101820, 18, 42);
    this.camera = new THREE.PerspectiveCamera(40, 1, 0.1, 100);
    this.camera.position.set(9.8, 4.3, 11.5); this.camera.lookAt(0, 1.1, 0);
    // Reserve the left side for garage controls and keep the whole car in view.
    this.displayOffset = new THREE.Vector3(2.35, 0, -2.05);
    this.scene.add(new THREE.HemisphereLight(0xc8e6ff, 0x1b2027, 1.15));
    this.key = new THREE.SpotLight(0xf7f4eb, 220, 36, Math.PI / 4, 0.4, 1.5); this.key.position.set(1, 11, 3); this.key.castShadow = quality !== 'low'; this.scene.add(this.key, this.key.target);
    const rimLight = new THREE.PointLight(0x60b6ff, 80, 26); rimLight.position.set(-7, 4, -4); this.scene.add(rimLight);
    const warm = new THREE.PointLight(0xff654c, 34, 20); warm.position.set(7, 2, -5); this.scene.add(warm);

    const floor = new THREE.Mesh(new THREE.PlaneGeometry(70, 70), new THREE.MeshStandardMaterial({ color: 0x14191f, roughness: 0.22, metalness: 0.62 }));
    floor.rotation.x = -Math.PI / 2; floor.position.y = -0.025; floor.receiveShadow = true; this.scene.add(floor);
    const turntable = new THREE.Mesh(new THREE.CylinderGeometry(5.1, 5.35, 0.18, 64), new THREE.MeshStandardMaterial({ color: 0x292f36, roughness: 0.28, metalness: 0.72 }));
    turntable.position.copy(this.displayOffset).add(new THREE.Vector3(0,0.02,0)); turntable.receiveShadow = true; this.scene.add(turntable); this.turntable = turntable;
    const ring = new THREE.Mesh(new THREE.TorusGeometry(4.85, 0.035, 8, 96), new THREE.MeshBasicMaterial({ color: 0xe03a3e }));
    ring.rotation.x = Math.PI / 2; ring.position.copy(this.displayOffset).add(new THREE.Vector3(0,0.125,0)); this.scene.add(ring); this.ring=ring;

    this._buildGarage(); this.updateCar(this.livery);
    this.resizeHandler = () => this.resize(); addEventListener('resize', this.resizeHandler); this.resize();
    this.running = false; this.last = 0;
  }

  _buildGarage() {
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x171d24, roughness: 0.8, metalness: 0.18 });
    const back = new THREE.Mesh(new THREE.BoxGeometry(34, 12, 0.6), wallMat); back.position.set(0, 5.7, -10); this.scene.add(back);
    const sideL = new THREE.Mesh(new THREE.BoxGeometry(0.5, 12, 22), wallMat); sideL.position.set(-17, 5.7, 0); this.scene.add(sideL);
    const sideR = sideL.clone(); sideR.position.x = 17; this.scene.add(sideR);
    const stripeMat = new THREE.MeshBasicMaterial({ color: 0xe7edf0 });
    for (let i = 0; i < 5; i++) {
      const strip = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.045, 0.22), new THREE.MeshBasicMaterial({ color: i % 2 ? 0xb9d7f0 : 0xffffff }));
      strip.position.set(-8 + i * 4, 10.8, -1.5); this.scene.add(strip);
    }
    for (const x of [-11, 11]) {
      const chest = new THREE.Mesh(new THREE.BoxGeometry(2.7, 1.4, 1.25), new THREE.MeshStandardMaterial({ color: 0x343d46, roughness: 0.42, metalness: 0.55 }));
      chest.position.set(x, 0.72, -7); chest.castShadow = true; this.scene.add(chest);
      for (let drawer = 0; drawer < 3; drawer++) {
        const handle = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.035, 0.035), stripeMat); handle.position.set(x, 0.42 + drawer * 0.3, -6.35); this.scene.add(handle);
      }
    }
    const tireMat = new THREE.MeshStandardMaterial({ color: 0x101216, roughness: 0.95 });
    for (const x of [-13.8, 13.8]) for (let row = 0; row < 3; row++) {
      const tire = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.19, 10, 24), tireMat); tire.position.set(x, 0.4 + row * 0.82, -3.5); tire.castShadow = true; this.scene.add(tire);
    }
    for (const x of [-15.8, 15.8]) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.15, 9.5, 0.15), wallMat); post.position.set(x, 4.7, -5); this.scene.add(post);
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.12, 8.2, 0.16), new THREE.MeshBasicMaterial({ color: 0xcbe6ff })); lamp.position.set(x + (x < 0 ? 0.15 : -0.15), 5.2, -4.5); this.scene.add(lamp);
    }
  }

  updateCar(livery) {
    if (this.car) {
      this.scene.remove(this.car.group);
      this.car.group.traverse(obj => { obj.geometry?.dispose(); if (Array.isArray(obj.material)) obj.material.forEach(m => {m.map?.dispose();m.dispose()}); else if(obj.material){obj.material.map?.dispose();obj.material.dispose()} });
    }
    this.livery = { ...palette, ...livery };
    this.car = buildCar(this.livery); this.car.group.position.copy(this.displayOffset).add(new THREE.Vector3(0,0.16,0)); this.car.group.traverse(o => { if (o.isMesh) o.castShadow = true; });
    this.scene.add(this.car.group);
  }

  setQuality(quality) {
    this.quality = quality; this.renderer.setPixelRatio(Math.min(devicePixelRatio, quality === 'low' ? 1 : quality === 'medium' ? 1.3 : 1.8));
    this.renderer.shadowMap.enabled = quality !== 'low'; this.key.castShadow = quality === 'high'; this.key.shadow.mapSize.set(quality === 'high' ? 1024 : 512, quality === 'high' ? 1024 : 512);
    this.renderer.shadowMap.needsUpdate = true;
  }

  resize() {
    const w = this.container.clientWidth || innerWidth, h = this.container.clientHeight || innerHeight;
    this.displayOffset.set(w < 760 ? 0.7 : 2.35, 0, w < 760 ? -0.6 : -2.05);
    if(this.turntable)this.turntable.position.copy(this.displayOffset).add(new THREE.Vector3(0,0.02,0));
    if(this.ring)this.ring.position.copy(this.displayOffset).add(new THREE.Vector3(0,0.125,0));
    if(this.car)this.car.group.position.copy(this.displayOffset).add(new THREE.Vector3(0,0.16,0));
    this.renderer.setSize(w, h); this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
  }

  start() { if (this.running) return; this.running = true; this.last = performance.now(); this.frameId = requestAnimationFrame(t => this.frame(t)); }
  frame(now) {
    if (!this.running) return;
    const dt = Math.min(0.05, (now - this.last) / 1000); this.last = now;
    this.turntable.rotation.y += dt * 0.22;
    this.car.group.rotation.y += dt * 0.22;
    this.renderer.render(this.scene, this.camera); this.frameId = requestAnimationFrame(t => this.frame(t));
  }
  stop() { this.running = false; cancelAnimationFrame(this.frameId); }
}
