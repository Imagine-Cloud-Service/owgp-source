// All tunable numbers live here. SI units (m, kg, N, s, rad) unless noted.
export const PHYSICS = {
  m: 798,            // car + driver mass, kg
  a: 1.9, b: 1.7,    // CG -> front axle, CG -> rear axle, m
  Iz: 1100,          // yaw inertia, kg*m^2
  rho: 1.2, CdA: 1.1, ClA: 4.0,   // air density, drag area, downforce area
  aeroFront: 0.42,   // share of downforce on the front axle
  mu: 2.0,           // peak tyre friction (dry slick)
  kf: 15, kr: 17,    // cornering stiffness per N of load (rear stiffer = stable)
  power: 560000,     // W
  brakeMax: 45000,   // N
  rolling: 0.015,
  maxSteer: 0.32,    // rad at low speed
  steerFade: 40,     // m/s at which steering authority halves-ish
  gearTop: [28, 44, 58, 70, 81, 91, 101, 112], // m/s at redline per gear
  idleRpm: 4000, redRpm: 15000,
};

// Control points follow the published Grand Prix circuit diagrams. Curves are
// normalized to the official centreline lap length in Track.js; point spacing
// describes corner/straight proportions, not surveyed latitude/longitude.
export const TRACKS = {
  monza: {
    name: 'Autodromo Nazionale Monza', venue: 'park', targetLength: 5793,
    mapSource: 'https://www.monzanet.it/en/circuit/',
    width: 12, kerb: 1.1, wallOffset: 24, samples: 1500, direction: 'clockwise',
    points: [[0,0],[160,0],[320,0],[470,0],[590,0],[650,18],[635,52],[690,72],[735,35],[720,-10],[790,-40],[900,-48],[1000,-8],[1045,70],[1030,150],[960,195],[875,188],[820,158],[795,115],[820,83],[780,45],[700,20],[590,22],[500,60],[425,120],[390,205],[345,250],[295,238],[275,198],[235,185],[190,222],[130,280],[50,322],[-55,325],[-145,292],[-205,230],[-205,170],[-165,145],[-155,105],[-195,78],[-250,80],[-295,42],[-310,-20],[-275,-80],[-195,-105],[-105,-115],[-20,-150],[5,-215],[70,-278],[175,-308],[300,-294],[420,-245],[510,-175],[560,-100],[555,-50],[470,-24],[320,-15],[160,-6]],
    drsZones: [[0.015,0.14],[0.44,0.53]],
    pit: { start: 0.92, end: 0.99, box: 0.955, offset: 9.4, width: 4.4 },
  },
  monaco: {
    name: 'Circuit de Monaco', venue: 'street', targetLength: 3337,
    mapSource: 'https://www.fia.com/system/files/decision-document/2025_monaco_grand_prix_-_race_directors_event_notes_-_circuit_map_pit_lane_map_ers_battery_containment_area_red_zones.pdf',
    width: 10.5, kerb: 0.55, wallOffset: 11.5, samples: 1500, direction: 'clockwise',
    points: [[0,0],[65,0],[135,0],[190,0],[218,14],[218,45],[198,66],[160,72],[125,88],[111,120],[92,148],[62,158],[42,145],[45,119],[69,100],[100,91],[132,100],[150,126],[151,153],[131,177],[99,183],[70,171],[53,151],[30,145],[6,158],[-20,146],[-32,123],[-19,102],[8,91],[31,73],[44,48],[66,33],[108,32],[157,35],[205,42],[249,44],[278,58],[286,82],[269,100],[252,118],[258,141],[285,153],[315,147],[333,126],[326,101],[304,82],[278,67],[247,59],[219,48],[192,34],[170,12],[142,-6],[99,-10],[52,-8]],
    drsZones: [[0.015,0.09]],
    pit: { start: 0.91, end: 0.99, box: 0.95, offset: 8.3, width: 4.1 },
  },
  spa: {
    name: 'Circuit de Spa-Francorchamps', venue: 'forest', targetLength: 7004,
    mapSource: 'https://www.formula1.com/en/information/belgium-circuit-de-spa-francorchamps.3LltuYaAXVRU8iezEsjzGw',
    width: 12, kerb: 1.1, wallOffset: 25, samples: 1700, direction: 'clockwise',
    points: [[0,0],[120,0],[270,4],[420,28],[555,78],[660,157],[714,252],[694,336],[650,406],[680,480],[755,544],[880,585],[1020,597],[1152,568],[1240,511],[1278,439],[1244,377],[1170,342],[1072,315],[1006,269],[1017,209],[1072,162],[1048,113],[987,91],[915,104],[835,136],[744,139],[660,106],[580,50],[501,-22],[443,-112],[416,-215],[383,-325],[325,-416],[239,-478],[146,-475],[78,-431],[54,-365],[86,-296],[146,-239],[181,-172],[157,-103],[97,-52],[30,-23]],
    drsZones: [[0.09,0.2],[0.67,0.79]],
    pit: { start: 0.94, end: 0.995, box: 0.968, offset: 9.5, width: 4.5 },
  },
  interlagos: {
    name: 'Interlagos — Autódromo José Carlos Pace', venue: 'stadium', targetLength: 4309,
    mapSource: 'https://autodromodeinterlagos.prefeitura.sp.gov.br/pistaoficial',
    width: 13.5, kerb: 1.0, wallOffset: 23, samples: 1500, direction: 'counterclockwise',
    points: [[0,0],[-110,0],[-250,0],[-390,0],[-505,6],[-580,30],[-623,74],[-618,111],[-580,137],[-529,126],[-480,102],[-436,116],[-396,165],[-363,232],[-332,300],[-285,346],[-230,355],[-186,326],[-151,274],[-117,215],[-81,159],[-33,123],[26,114],[87,132],[150,170],[211,197],[266,181],[290,143],[279,104],[249,66],[228,24],[188,-4],[143,-44],[112,-104],[80,-169],[38,-215],[6,-196],[-4,-153],[15,-111],[10,-78],[-30,-52],[-76,-40],[-122,-27],[-170,-15],[-218,-9],[-275,-7],[-340,-4],[-420,-1],[-500,0],[-580,-4]],
    drsZones: [[0.015,0.12],[0.43,0.54]],
    pit: { start: 0.0, end: 0.1, box: 0.055, offset: 10.0, width: 4.6 },
  },
  suzuka: {
    name: 'Suzuka International Racing Course', venue: 'technical', targetLength: 5807,
    mapSource: 'https://www.suzukacircuit.jp/eng/course_s/',
    width: 13, kerb: 1.0, wallOffset: 24, samples: 1700, direction: 'clockwise', figureEight: true,
    points: [[0,0],[90,2],[190,8],[286,30],[350,72],[370,121],[347,165],[305,173],[268,147],[238,183],[209,227],[171,246],[135,222],[110,256],[77,289],[36,280],[7,245],[-22,206],[-59,177],[-111,166],[-166,183],[-212,162],[-237,122],[-227,74],[-190,38],[-133,22],[-79,21],[-30,32],[0,0],[57,-25],[122,-65],[183,-113],[244,-158],[290,-211],[295,-261],[264,-300],[217,-312],[171,-290],[126,-250],[83,-208],[39,-172],[1,-140],[-41,-106],[-78,-68],[-53,-34],[-25,-15]],
    drsZones: [[0.01,0.12],[0.53,0.64]],
    pit: { start: 0.91, end: 0.99, box: 0.95, offset: 10.0, width: 4.5 },
  },
};
export const TRACK = TRACKS.monza;

export const RACE = { laps: 3, opponents: 5, pitServiceSeconds: 4.5, pitSpeedKmh: 70, safetyCarSeconds: 22, carHitRadius: 3.8 };
export const WEATHER = { dry: 0, changeable: 0.38, wet: 0.78 };
export const ERS = { capacityMJ: 4, deploymentKW: 120, regenKW: 70 };
export const TYRES = {
  soft: { grip: 1.08, wear: 1.5 }, medium: { grip: 1, wear: 1 }, hard: { grip: 0.94, wear: 0.68 },
};

export const WEATHER_DEFAULT = { wetness: 0 };
export const STEP = 1 / 240; // fixed physics step
